G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-08-09T09:41:18-07:00*
G04 #@! TF.ProjectId,carrier,63617272-6965-4722-9e6b-696361645f70,A*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-09 09:41:18*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.000000*%
%ADD11R,1.800000X1.800000*%
%ADD12C,1.800000*%
%ADD13RoundRect,0.320000X-1.280000X1.280000X-1.280000X-1.280000X1.280000X-1.280000X1.280000X1.280000X0*%
%ADD14C,3.200000*%
%ADD15C,1.600000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,MOD1*
X179750000Y-98800000D03*
X118250000Y-98800000D03*
X179750000Y-126800000D03*
X118250000Y-126800000D03*
D11*
X124600000Y-127190000D03*
D12*
X124600000Y-98410000D03*
D11*
X122060000Y-127190000D03*
D12*
X122060000Y-98410000D03*
D11*
X150160000Y-127290000D03*
D12*
X152700000Y-127290000D03*
X155240000Y-127290000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X112482500Y-109200000D03*
D14*
X112482500Y-114200000D03*
D15*
X111252500Y-118050000D03*
X109252500Y-118050000D03*
G04 #@! TD*
M02*
